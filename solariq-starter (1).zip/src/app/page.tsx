 "use client";

import { useMemo, useState } from "react";
import {
  Activity, ArrowDownRight, ArrowUpRight, Bell, CalendarDays, Camera,
  Check, ChevronRight, ClipboardList, Clock3, FileText, Handshake,
  HeartHandshake, Home, LayoutDashboard, MapPin, Menu, Plus, Search,
  Settings, Target, TrendingUp, Upload, Users, Zap
} from "lucide-react";

type Lead = {
  id: number; name: string; address: string; annualKwh: number;
  status: "Nurture" | "Appointment" | "New"; next: string; note: string;
};

const initialLeads: Lead[] = [
  { id: 1, name: "Jordan Miller", address: "Pittsburgh, PA", annualKwh: 18400, status: "Appointment", next: "Tomorrow · 5:30 PM", note: "Wants spouse present; interested in reducing utility costs." },
  { id: 2, name: "Taylor Brooks", address: "Bethel Park, PA", annualKwh: 22100, status: "Nurture", next: "Friday · 4:00 PM", note: "Busy this week. Asked for a call after reviewing the bill." },
  { id: 3, name: "Morgan Davis", address: "Upper St. Clair, PA", annualKwh: 15600, status: "Nurture", next: "Nov 10 · 6:00 PM", note: "Interested but wants to do more research first." },
];

const money = (n: number) => n.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 });
const number = (n: number) => n.toLocaleString("en-US");

export default function HomePage() {
  const [active, setActive] = useState("Overview");
  const [leads, setLeads] = useState(initialLeads);
  const [doors, setDoors] = useState(85);
  const [conversations, setConversations] = useState(12);
  const [bills, setBills] = useState(5);
  const [appointments, setAppointments] = useState(2);
  const [showLeadForm, setShowLeadForm] = useState(false);
  const [name, setName] = useState("");
  const [address, setAddress] = useState("");
  const [kwh, setKwh] = useState("");
  const [note, setNote] = useState("");
  const [query, setQuery] = useState("");

  const totalNurtureKwh = useMemo(
    () => leads.filter(l => l.status === "Nurture").reduce((sum, l) => sum + l.annualKwh, 0),
    [leads]
  );

  const addLead = () => {
    if (!name.trim() || !address.trim()) return;
    setLeads(prev => [{
      id: Date.now(), name: name.trim(), address: address.trim(),
      annualKwh: Number(kwh) || 0, status: "Nurture", next: "Set follow-up",
      note: note.trim() || "No conversation notes added."
    }, ...prev]);
    setName(""); setAddress(""); setKwh(""); setNote(""); setShowLeadForm(false); setActive("Nurture");
  };

  const nav = [
    { label: "Overview", icon: LayoutDashboard },
    { label: "Capture", icon: Camera },
    { label: "Convert", icon: CalendarDays },
    { label: "Nurture", icon: HeartHandshake },
  ];

  return (
    <main className="min-h-screen bg-[#090d16] text-[#edf3fb]">
      <div className="mx-auto flex min-h-screen max-w-[1500px]">
        <aside className="hidden w-[245px] shrink-0 border-r border-white/8 bg-[#0d1320] p-5 lg:flex lg:flex-col">
          <div className="mb-10 flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-sky-500/15 text-sky-400"><Zap size={22}/></div>
            <div><div className="text-lg font-bold tracking-tight">Solar<span className="text-sky-400">IQ</span></div><div className="text-[10px] uppercase tracking-[.22em] text-slate-500">Sales intelligence</div></div>
          </div>
          <div className="mb-3 px-3 text-[10px] font-semibold uppercase tracking-[.2em] text-slate-500">Workspace</div>
          <nav className="space-y-1">
            {nav.map(({label, icon: Icon}) => (
              <button key={label} onClick={() => setActive(label)} className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm transition ${active === label ? "bg-sky-500/12 font-semibold text-sky-300" : "text-slate-400 hover:bg-white/5 hover:text-white"}`}>
                <Icon size={18}/>{label}{label === "Nurture" && <span className="ml-auto rounded-full bg-amber-400/15 px-2 py-0.5 text-[10px] text-amber-300">{leads.filter(l=>l.status==="Nurture").length}</span>}
              </button>
            ))}
          </nav>
          <div className="mt-9 mb-3 px-3 text-[10px] font-semibold uppercase tracking-[.2em] text-slate-500">Account</div>
          <button className="flex items-center gap-3 rounded-xl px-3 py-3 text-left text-sm text-slate-400 hover:bg-white/5"><Settings size={18}/>Settings</button>
          <div className="mt-auto rounded-2xl border border-sky-400/15 bg-sky-400/5 p-4">
            <div className="mb-2 flex items-center gap-2 text-sm font-semibold text-sky-200"><Target size={16}/>Weekly target</div>
            <div className="text-2xl font-bold">100 <span className="text-xs font-normal text-slate-500">doors / day</span></div>
            <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-white/10"><div className="h-full w-[85%] rounded-full bg-sky-400"/></div>
            <div className="mt-2 text-xs text-slate-500">85% of today's target</div>
          </div>
        </aside>

        <section className="min-w-0 flex-1">
          <header className="sticky top-0 z-10 flex h-[76px] items-center justify-between border-b border-white/8 bg-[#090d16]/90 px-5 backdrop-blur-xl md:px-8">
            <div className="flex items-center gap-3">
              <div className="grid h-9 w-9 place-items-center rounded-xl bg-sky-500/15 text-sky-400 lg:hidden"><Zap size={19}/></div>
              <div><div className="text-sm font-semibold">{active === "Overview" ? "Good evening" : active}</div><div className="text-xs text-slate-500">Wednesday, November 4</div></div>
            </div>
            <div className="flex items-center gap-2">
              <div className="hidden items-center gap-2 rounded-xl border border-white/10 bg-white/[.03] px-3 py-2 text-xs text-slate-500 sm:flex"><Search size={14}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search leads..." className="w-28 bg-transparent outline-none placeholder:text-slate-600"/></div>
              <button className="relative rounded-xl border border-white/10 p-2.5 text-slate-400 hover:text-white"><Bell size={17}/><span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-sky-400"/></button>
              <div className="grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-sky-400 to-indigo-500 text-xs font-bold text-white">CC</div>
            </div>
          </header>

          <div className="mx-auto max-w-[1250px] space-y-7 p-5 md:p-8">
            <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
              <div><div className="mb-2 text-xs font-semibold uppercase tracking-[.22em] text-sky-400">Capture. Convert. Nurture.</div><h1 className="text-3xl font-semibold tracking-tight md:text-4xl">{active === "Overview" ? "Your sales at a glance." : active === "Capture" ? "Capture every opportunity." : active === "Convert" ? "Move opportunities forward." : "Relationships create revenue."}</h1><p className="mt-2 max-w-xl text-sm text-slate-400">{active === "Overview" ? "Know your activity, pipeline, and the next best action." : active === "Capture" ? "Log doors, conversations, bills, and homeowner energy profiles." : active === "Convert" ? "Track appointments from scheduled to completed and closed." : "Stay connected with homeowners who aren't ready to schedule yet."}</p></div>
              <button onClick={()=>setShowLeadForm(true)} className="inline-flex items-center justify-center gap-2 rounded-xl bg-sky-500 px-4 py-3 text-sm font-semibold text-white shadow-lg shadow-sky-500/15 transition hover:bg-sky-400"><Plus size={17}/>New lead</button>
            </div>

            {active === "Capture" && (
              <div className="grid gap-5 xl:grid-cols-[1.1fr_.9fr]">
                <div className="rounded-2xl border border-white/10 bg-[#101827] p-5">
                  <div className="mb-1 text-lg font-semibold">Quick activity log</div><p className="mb-5 text-sm text-slate-500">Keep your field activity accurate as you go.</p>
                  <div className="grid grid-cols-2 gap-3">
                    {[["Doors",doors,setDoors],["Conversations",conversations,setConversations],["Bills",bills,setBills],["Appointments",appointments,setAppointments]].map(([label,value,setter]: any)=>(
                      <div key={label} className="rounded-xl border border-white/8 bg-white/[.025] p-4"><div className="text-xs text-slate-500">{label}</div><div className="my-2 text-3xl font-semibold">{value}</div><button onClick={()=>setter((v:number)=>v+1)} className="flex items-center gap-1 text-xs font-semibold text-sky-300"><Plus size={14}/>Add one</button></div>
                    ))}
                  </div>
                </div>
                <div className="rounded-2xl border border-dashed border-sky-400/30 bg-sky-400/[.04] p-5">
                  <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-sky-400/10 text-sky-300"><Upload size={20}/></div>
                  <div className="text-lg font-semibold">Utility bill capture</div><p className="mt-2 text-sm leading-6 text-slate-400">The next milestone will let you photograph a bill and extract annual kWh, utility provider, service address, and customer name for review.</p>
                  <div className="mt-5 rounded-xl border border-white/8 bg-[#0b1220] p-3 text-xs text-slate-500"><FileText size={15} className="mb-2 text-sky-300"/>Bill image upload and AI extraction are planned next. This prototype does not upload or process documents yet.</div>
                </div>
              </div>
            )}

            {active === "Convert" && (
              <div className="rounded-2xl border border-white/10 bg-[#101827] p-5">
                <div className="mb-1 text-lg font-semibold">Appointment pipeline</div><p className="mb-5 text-sm text-slate-500">Each appointment should carry its original lead and verified annual usage.</p>
                <div className="grid gap-3 md:grid-cols-3">
                  <Metric label="Scheduled" value={appointments.toString()} sub="Appointments on the calendar" icon={<CalendarDays size={17}/>} />
                  <Metric label="Annual kWh booked" value="36,800" sub="Illustrative pipeline usage" icon={<Zap size={17}/>} />
                  <Metric label="Deals closed" value="1" sub="Example performance data" icon={<Check size={17}/>} />
                </div>
                <div className="mt-5 space-y-3">{leads.filter(l=>l.status==="Appointment").map(l=><LeadRow key={l.id} lead={l}/>)}</div>
              </div>
            )}

            {active === "Nurture" && (
              <div className="space-y-4">
                <div className="grid gap-3 md:grid-cols-3">
                  <Metric label="Active nurture leads" value={leads.filter(l=>l.status==="Nurture").length.toString()} sub="People to stay connected with" icon={<HeartHandshake size={17}/>} />
                  <Metric label="Annual kWh in nurture" value={number(totalNurtureKwh)} sub="Verified or rep-entered usage" icon={<Zap size={17}/>} />
                  <Metric label="Follow-ups to plan" value={leads.filter(l=>l.next==="Set follow-up").length.toString()} sub="Leads missing a next action" icon={<Clock3 size={17}/>} />
                </div>
                <div className="rounded-2xl border border-white/10 bg-[#101827] p-5"><div className="mb-4 text-lg font-semibold">Relationship follow-up</div>{leads.filter(l=>l.status==="Nurture" && (l.name+" "+l.address).toLowerCase().includes(query.toLowerCase())).map(l=><LeadRow key={l.id} lead={l}/> )}</div>
              </div>
            )}

            {active === "Overview" && (
              <>
                <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                  <Metric label="Doors knocked" value={doors.toString()} sub="Today's field activity" icon={<Home size={17}/>} trend="On pace" />
                  <Metric label="Bills collected" value={bills.toString()} sub={`${conversations ? Math.round(bills/conversations*100) : 0}% of conversations`} icon={<FileText size={17}/>} trend="Track quality" />
                  <Metric label="Appointments set" value={appointments.toString()} sub="Scheduled opportunities" icon={<CalendarDays size={17}/>} trend="Pipeline" />
                  <Metric label="Nurture leads" value={leads.filter(l=>l.status==="Nurture").length.toString()} sub="Future appointment potential" icon={<HeartHandshake size={17}/>} trend="Stay connected" />
                </div>
                <div className="grid gap-5 xl:grid-cols-[1.25fr_.75fr]">
                  <div className="rounded-2xl border border-white/10 bg-[#101827] p-5">
                    <div className="flex items-center justify-between"><div><div className="font-semibold">Activity funnel</div><div className="mt-1 text-xs text-slate-500">Today's progress · illustrative starting values</div></div><Activity size={18} className="text-sky-300"/></div>
                    <div className="mt-6 space-y-5">
                      <Funnel label="Doors knocked" value={doors} max={100}/>
                      <Funnel label="Conversations" value={conversations} max={doors}/>
                      <Funnel label="Bills collected" value={bills} max={doors}/>
                      <Funnel label="Appointments" value={appointments} max={doors}/>
                    </div>
                    <div className="mt-6 grid grid-cols-2 gap-3 border-t border-white/8 pt-5">
                      <div><div className="text-xs text-slate-500">Conversation rate</div><div className="mt-1 text-xl font-semibold">{doors ? (conversations/doors*100).toFixed(1) : "0.0"}%</div></div>
                      <div><div className="text-xs text-slate-500">Bill-to-appointment</div><div className="mt-1 text-xl font-semibold">{bills ? (appointments/bills*100).toFixed(1) : "0.0"}%</div></div>
                    </div>
                  </div>
                  <div className="rounded-2xl border border-white/10 bg-[#101827] p-5">
                    <div className="font-semibold">Next best actions</div><div className="mt-1 text-xs text-slate-500">Keep opportunities moving</div>
                    <div className="mt-5 space-y-4">
                      <Action icon={<Clock3 size={17}/>} title="Follow up with Taylor" detail="Bill reviewed · check in Friday"/>
                      <Action icon={<CalendarDays size={17}/>} title="Prepare for Jordan's visit" detail="Tomorrow at 5:30 PM"/>
                      <Action icon={<HeartHandshake size={17}/>} title="Re-engage Morgan" detail="Researching options · Nov 10"/>
                    </div>
                  </div>
                </div>
                <div className="rounded-2xl border border-white/10 bg-[#101827] p-5">
                  <div className="mb-4 flex items-center justify-between"><div><div className="font-semibold">Recent opportunities</div><div className="mt-1 text-xs text-slate-500">Leads connected to your activity</div></div><button onClick={()=>setActive("Nurture")} className="text-xs font-semibold text-sky-300">View nurture <ChevronRight size={13} className="inline"/></button></div>
                  {leads.slice(0,3).map(l=><LeadRow key={l.id} lead={l}/>)}
                </div>
              </>
            )}
          </div>
        </section>
      </div>

      <div className="fixed bottom-0 left-0 right-0 z-20 grid grid-cols-4 border-t border-white/10 bg-[#0d1320]/95 p-2 backdrop-blur-xl lg:hidden">
        {nav.map(({label,icon:Icon})=><button key={label} onClick={()=>setActive(label)} className={`flex flex-col items-center gap-1 rounded-lg py-2 text-[10px] ${active===label?"text-sky-300":"text-slate-500"}`}><Icon size={19}/>{label}</button>)}
      </div>

      {showLeadForm && <div className="fixed inset-0 z-30 flex items-end justify-center bg-black/70 p-0 backdrop-blur-sm sm:items-center sm:p-5">
        <div className="w-full max-w-lg rounded-t-3xl border border-white/10 bg-[#111a2a] p-6 sm:rounded-2xl">
          <div className="mb-5 flex items-center justify-between"><div><div className="text-lg font-semibold">Capture a new lead</div><div className="text-xs text-slate-500">Add the conversation now; enrich it later.</div></div><button onClick={()=>setShowLeadForm(false)} className="rounded-lg px-3 py-2 text-slate-400 hover:bg-white/5">✕</button></div>
          <div className="space-y-3">
            <Field label="Homeowner name" value={name} onChange={setName} placeholder="Full name"/>
            <Field label="Property / service address" value={address} onChange={setAddress} placeholder="Street, city, state"/>
            <Field label="Annual electricity usage (kWh)" value={kwh} onChange={setKwh} placeholder="e.g. 18400" type="number"/>
            <label className="block"><span className="mb-1.5 block text-xs text-slate-400">Conversation notes</span><textarea value={note} onChange={e=>setNote(e.target.value)} rows={3} placeholder="What matters to this homeowner? What did they ask?" className="w-full rounded-xl border border-white/10 bg-[#0b1220] px-3 py-3 text-sm outline-none focus:border-sky-400"/></label>
          </div>
          <div className="mt-5 flex gap-3"><button onClick={()=>setShowLeadForm(false)} className="flex-1 rounded-xl border border-white/10 px-4 py-3 text-sm text-slate-300">Cancel</button><button onClick={addLead} disabled={!name.trim()||!address.trim()} className="flex-1 rounded-xl bg-sky-500 px-4 py-3 text-sm font-semibold text-white disabled:opacity-40">Save lead</button></div>
        </div>
      </div>}
      <div className="h-20 lg:hidden"/>
    </main>
  );
}

function Metric({label,value,sub,icon,trend}:{label:string;value:string;sub:string;icon:React.ReactNode;trend?:string}) {
  return <div className="rounded-2xl border border-white/10 bg-[#101827] p-4"><div className="flex items-center justify-between"><span className="text-xs text-slate-400">{label}</span><span className="text-sky-300">{icon}</span></div><div className="mt-3 text-3xl font-semibold tracking-tight">{value}</div><div className="mt-1 text-xs text-slate-500">{sub}</div>{trend&&<div className="mt-3 text-[10px] font-semibold uppercase tracking-wider text-sky-300">{trend}</div>}</div>;
}
function Funnel({label,value,max}:{label:string;value:number;max:number}) {
  const pct = max ? Math.min(100,value/max*100) : 0;
  return <div><div className="mb-2 flex justify-between text-sm"><span className="text-slate-300">{label}</span><span className="font-semibold tabular-nums">{value}</span></div><div className="h-2 overflow-hidden rounded-full bg-white/8"><div className="h-full rounded-full bg-gradient-to-r from-sky-500 to-cyan-300" style={{width:`${pct}%`}}/></div></div>;
}
function Action({icon,title,detail}:{icon:React.ReactNode;title:string;detail:string}) {
  return <div className="flex gap-3"><div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-sky-400/10 text-sky-300">{icon}</div><div><div className="text-sm font-medium">{title}</div><div className="mt-1 text-xs text-slate-500">{detail}</div></div></div>;
}
function LeadRow({lead}:{lead:Lead}) {
  return <div className="flex flex-col gap-3 border-t border-white/8 py-4 first:border-0 first:pt-0 sm:flex-row sm:items-center sm:justify-between"><div className="min-w-0"><div className="flex flex-wrap items-center gap-2"><span className="text-sm font-semibold">{lead.name}</span><span className={`rounded-full px-2 py-0.5 text-[10px] ${lead.status==="Appointment"?"bg-sky-400/10 text-sky-300":"bg-amber-400/10 text-amber-300"}`}>{lead.status}</span></div><div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500"><span className="inline-flex items-center gap-1"><MapPin size={12}/>{lead.address}</span><span className="inline-flex items-center gap-1"><Zap size={12}/>{number(lead.annualKwh)} kWh / yr</span></div><div className="mt-2 text-xs text-slate-400">{lead.note}</div></div><div className="shrink-0 text-xs text-slate-400"><Clock3 size={13} className="mr-1 inline"/>{lead.next}</div></div>;
}
function Field({label,value,onChange,placeholder,type="text"}:{label:string;value:string;onChange:(v:string)=>void;placeholder:string;type?:string}) {
  return <label className="block"><span className="mb-1.5 block text-xs text-slate-400">{label}</span><input type={type} value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder} className="w-full rounded-xl border border-white/10 bg-[#0b1220] px-3 py-3 text-sm outline-none focus:border-sky-400"/></label>;
}
