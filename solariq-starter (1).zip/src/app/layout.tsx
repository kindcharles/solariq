import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "SolarIQ — Capture. Convert. Nurture.",
  description: "A solar sales performance and relationship management workspace.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
