# SolarIQ

**Capture. Convert. Nurture.**

A mobile-first solar sales companion prototype built with Next.js, TypeScript, and Tailwind CSS.

## What's included

- Responsive dashboard with sales activity metrics
- Quick activity counters for doors, conversations, bills, and appointments
- Lead capture form with annual kWh and conversation notes
- Appointment pipeline placeholder
- Nurture list and annual kWh summary
- Sample data clearly intended for demonstration

## Important prototype notes

This is a front-end prototype. Data is held in browser memory and resets on refresh. It does not yet:
- Persist leads or metrics to a database
- Upload or process utility bills
- Extract annual kWh with AI/OCR
- Connect to RepCard
- Send SMS, email, or push notifications
- Retrieve assessor / owner-of-record information

Do not enter real customer utility bills or sensitive customer data until authentication, database security, private storage, and retention controls are implemented.

## Run locally

Requires Node.js 20.9+.

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Deploy

1. Create a new GitHub repository named `solariq`.
2. Upload or push this project to the repository.
3. Import the repository into Vercel.
4. Deploy using the default Next.js settings.

## Next build milestones

1. Supabase authentication and database with organization-scoped row-level security.
2. Persistent activity logging, leads, appointments, and follow-ups.
3. Private utility-bill upload and AI extraction with human verification of annual kWh.
4. Reminder and nurture workflows.
5. Reporting, conversion metrics, and commission tracking.

## Recommended core data model

- `leads`: homeowner/contact, service address, status, notes, owner verification
- `documents`: private bill file path, extraction result, confidence, consent record
- `energy_profiles`: utility, billing period, annual kWh, annual cost, verification
- `activities`: doors, conversations, bills, appointments, visits, outcomes
- `appointments`: location, date/time, lead, annual kWh snapshot, status
- `follow_ups`: lead, due date, preferred contact method, task, completion status
- `deals`: lead, system kW, contract value, commission, close date

Annual kWh should be sourced from the bill when available, displayed with the source evidence, and confirmed by the rep before being treated as verified.
